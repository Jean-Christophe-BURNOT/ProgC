void lire_fichier(char *);
void ecrire_dans_fichier(char *, char *);
