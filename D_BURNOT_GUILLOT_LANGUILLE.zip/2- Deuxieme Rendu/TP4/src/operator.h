/*
 * Fichier header
 */

int somme(int, int);

int difference(int, int);

int produit(int, int);

int quotient(int, int);

int modulo(int, int);

int et(int, int);

int ou(int, int);

int negation(int);
