# Bibliothèques
* stdio.h
* stdlib.h
* time.h
* fcntl.h
* unistd.h
* string.h

# Références
* cours de C
* OpenClassrom

# Difficulté
### Jean-Christophe
* Notion de liste chaînées travail à la maison
* Warning enlevé manuellement en incrémentant un variable

### Antony
* Les exo autours du programme fichier.c plus compliqués

### Antoine
* faire attention à bien enlever le \n à la fin d'un input

# Commentaires
* chercherfichier.c n'utilise pas file.c

