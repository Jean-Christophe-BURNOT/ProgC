# Bibliothèques
* stdio.h
* stdlib.h
* sys/types.h
* sys/socket.h
* sys/epoll.h
* netinet/in.h
* string.h
* unistd.h
* sys/types.h
* sys/socket.h
* sys/epoll.h
* netinet/in.h

# Références
* cours de C
* OpenClassrom
* tutorialspoint
* stackOverflow

# Difficulté
### Jean-Christophe
* compréhension du code

### Antony
* deteste le JSON

### Antoine
* compréhension du code difficile
* changement de méthode d'input pour le remplacer en JSON stdin->JSON
* decouverte valeurs parasites dans la transmission (filtrage)

# Commentaires
* Il faut parfois relancer le serveur

