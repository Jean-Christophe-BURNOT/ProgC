1. Jean-Christophe BURNOT 
2. Antoine Languille
3. Antony Guillot
4. Arthur Pey (a travaillé avec Antony en séance)
