# Bibliothèques
* stdio.h
* stdlib.h
* string.h
* dirent.h
* unistd.h
* sys/types.h
* sys/socket.h
* netinet/in.h
* sys/epoll.h

# Références
* cours de C
* OpenClassrom
* tutorialspoint
* stackOverflow

# Difficulté
### Jean-Christophe
* repertoire en itératif plus difficile que récursif
* Dernier exercice vraiment difficile

### Antony
* repertoire en itératif plus difficile que récursif
* Difficultés de compréhension du code initial (donc difficultés à le modifier)

### Antoine
* Dernier exo je cite: "C'est galère"

# Commentaires
* Pas de commentaires

