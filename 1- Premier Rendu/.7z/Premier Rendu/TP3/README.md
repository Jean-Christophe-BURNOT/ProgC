# Bibliothèques
* stdlib.h
* time.h

# Références
* cours de C

# Difficulté
### Jean-Christophe
* Formule de la dichotomie (petite erreur de calcul) 

### Antony
* Erreur de formule dichotomie

### Antoine
* Code sur les couleurs compliqué

# Commentaires
* Pas de commentaires

