# Bibliothèques
* stdio.h
* bitconv.h (local) (à utiliser pour bits.c)

# Références
* Cours de C
* StackOverfow

# Difficulté
### Jean-Christophe
* Grosses difficultées sur la récursivité et les boucles
* Solutionner les core dumps

### Antony
* Les pointeurs

### Antoine
* Croissante
* L'exercice sur l'affichage sous format hexadécimal était compliqué en raison des cast de type nécessaire

# Commentaires
* Aucun

