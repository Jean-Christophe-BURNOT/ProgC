# Bibliothèques
* math.h (pour utiliser "M_PI") 
* stdlib.h
* limits.h
* float.h

# Références
* Open ClassRoom forums
* https://www.tutorialspoint.com/c_standard_library/limits_h.htm
* cours de programation

# Difficulté
### Jean-Christophe
* Les deux premiers codes se sont avérés plutôt simples, quelques fautes de syntaxe ont été difficiles à corriger.
* De grosses difficultés avec les bracket et la résolution de mon écran
* Hésitations sur la manière de gérer les { et }

### Antony
* exercice 1.6 et 1.9 (surtout le dernier) m'on demandé plus de reflections les precedents etait tres peu interessant et difficiles mais permettent une decouverte du language.

### Antoine
* Algorithmiquement le do/while fut un peu complexe
* Le dernier exercice fut difficile

# Commentaires
* L'exercice 2 est plus sophistiqué je me suis amusé à faire un choix utilisateur.
* L'exercice sur le binaire a été résolu avec les masque, il en existe une version presque fonctionnelle dans les test

