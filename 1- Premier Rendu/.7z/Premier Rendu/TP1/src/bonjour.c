//Imports des bibliothèques
#include <stdio.h>
#include <stdlib.h>
/*
 *Premier code en C pour tester le compilateur GCC realise
 *par mon idole Richard Stallman dans le projet GNU
 */

//Fonction principale appelée au lancement du programme
int main()
{
    printf("bonjour le monde!");
    //code de retour
    return 0;
}
