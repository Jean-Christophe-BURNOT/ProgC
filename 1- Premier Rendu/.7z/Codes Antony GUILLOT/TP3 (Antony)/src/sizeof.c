//biblioteques
#include <stdio.h>


int main() {

    printf("Taille de int est : %li\n",sizeof(int));
    printf("Taille de int * est : %li\n",sizeof(int *));
    printf("Taille de int ** est : %li\n",sizeof(int **));
    printf("Taille de char * est : %li\n",sizeof(char *));
    printf("Taille de char ** est : %li\n",sizeof(char **));
    printf("Taille de char ***  est : %li\n",sizeof(char ***));
    printf("Taille de float * est : %li\n",sizeof(float *));
    printf("Taille de float ** est : %li\n",sizeof(float **));
    printf("Taille de float *** est : %li\n",sizeof(float ***));

return 0;
}   