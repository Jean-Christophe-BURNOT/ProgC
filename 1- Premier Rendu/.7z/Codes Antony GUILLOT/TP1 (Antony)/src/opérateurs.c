//biblioteques
#include <stdio.h>

int main() {
    int a = 16;
    int b = 3;

    printf("Voici le resultat de a + b    : %i\n",a + b);
    printf("Voici le resultat de a - b    : %i\n",a - b);
    printf("Voici le resultat de a * b    : %i\n",a * b);
    printf("Voici le resultat de a / b    : %i\n",a / b);
    printf("Voici le resultat de a %% b    : %i\n",a % b);
    printf("Voici le resultat de a < b    : %i\n",a < b);
    printf("Voici le resultat de a <= b   : %i\n",a <= b);
    printf("Voici le resultat de a > b    : %i\n",a > b);
    printf("Voici le resultat de a >= b    : %i\n",a >= b);
    printf("Voici le resultat de a == b   : %i\n",a == b);
    printf("Voici le resultat de a != b   : %i\n",a != b);
    printf("Voici le resultat de a && b   : %i\n",a && b);
    printf("Voici le resultat de a || b   : %i\n",a || b);
    printf("Voici le resultat de !b   : %i\n", !b);
    printf("Voici le resultat de ~b   : %i\n", ~b);
    printf("Voici le resultat de a | b   : %i\n",a | b);
    printf("Voici le resultat de a & b   : %i\n",a & b);

return 0;
}