//biblioteques
#include <stdio.h>


int main() {

    printf("Taille de char est : %li\n",sizeof(char));
    printf("Taille de short est : %li\n",sizeof(short));
    printf("Taille de int est : %li\n",sizeof(int));
    printf("Taille de long int est : %li\n",sizeof(long int));
    printf("Taille de long long int est : %li\n",sizeof(long long int));
    printf("Taille de float est : %li\n",sizeof(float));
    printf("Taille de double est : %li\n",sizeof(double));
    printf("Taille de long double est : %li\n",sizeof(long double));

return 0;
}