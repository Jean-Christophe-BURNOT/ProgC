//biblioteques
#include <stdio.h>

int main() {

    char var1 = 'a';
    printf("Voici un char : %c\n",var1);

    short var2 = 1 ;
    printf("Voici un short : %hd\n",var2);

    int var3 = 1;
    printf("Voici un int : %i\n",var3);

    long int var4 = 17577;
    printf("Voici un long int : %ld\n",var4);

    long long int var5 = 175775757;
    printf("Voici un long long int : %lld\n",var5);

    float var6 = 1.253535;
    printf("Voici un float : %f\n",var6);

    double var7 = 1.2555757;
    printf("Voici un double : %g\n",var7);

    long double var8 = 1.2525557757;
    printf("Voici un long double : %Lg\n",var8);
    
    return 0;
}