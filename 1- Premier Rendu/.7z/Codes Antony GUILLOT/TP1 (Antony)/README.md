# Bibliothèques
* <stdio.h>
* <limits.h>

# Références
* https://www.tutorialspoint.com/c_standard_library/limits_h.htm
* cours de programation

# Difficulté
* exercice 1.6 et 1.9 (surtout le dernier) m'on demandé plus de reflections les precedents etait tres peu interessant et difficiles mais permettent une decouverte du language.

# Commentaires
* 
* 

