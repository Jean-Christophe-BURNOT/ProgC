# Bibliothèques
* math.h (pour utiliser "M_PI") 
* stdlib.h
* limits.h
* float.h

# Références
* Open ClassRoom forums
*

# Difficulté
* Les deux premiers codes se sont avérés plutôt simples, quelques fautes de syntaxe ont été difficiles à corriger.
* De grosses difficultés avec les bracket et la résolution de mon écran
* Hésitations sur la manière de gérer les { et }
* Difficultés à gérer le Binaire, j'ai du refaire mon code avec Hugo

# Commentaires
* L'exercice 2 est plus sophistiqué je me suis amusé à faire un choix utilisateur.
* L'exercice sur le binaire a été résolu avec les masque, il en existe une version presque fonctionnelle dans les test

