#include <stdio.h>
#include <stdlib.h>
/*
 *Premier code en C pour tester le compilateur GCC realise
 *par mon idole Richard Stallman dans le projet GNU
 */

int main()
{
    printf("bonjour le monde!");
    return 0;
}
