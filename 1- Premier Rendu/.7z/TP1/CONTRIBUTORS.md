1. Jean-Christophe BURNOT 
2. Antoine Languille
3. Anthony Guillot
4. Hugo Coutaud (Aide reçue pour l'exercice sur le Binaire)
