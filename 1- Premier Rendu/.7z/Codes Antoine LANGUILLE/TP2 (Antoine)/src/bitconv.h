void showbits(int);
