# Bibliothèques
* stdio.h
* bitconv.h (local) (à utiliser pour bits.c)

# Références
* Cours de C
* StackOverfow

# Difficulté
* Croissante
* L'exercice sur l'affichage sous format hexadécimal était compliqué en raison des cast de type nécessaire

# Commentaires
* Cf ci dessus
* 

