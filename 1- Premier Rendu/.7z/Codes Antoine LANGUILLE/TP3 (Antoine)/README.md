# Bibliothèques
* stdio.h
* stdlib.h

# Références
* Cours de C
*

# Difficulté
* Croissante, acceptable

# Commentaires
* Aucun
* 

