#include <stdio.h>
// import des librairies (ici pour interagir avec stdout)

/*
* Premier programme
*/

// Fonction principale appelée au lancement du programme
int main() {
	printf("bonjour le monde!\n");
	return 0; // code de retour du programme
}
