# Bibliothèques
* stdio.h
*

# Références
* Site tutorialspoint.com
* Le cours de programmation en C
* Site StackOverflow

# Difficulté
* Croissante, premiers exercices faciles et long, derniers longs et plus complexes
* Acceptable

# Commentaires
* Auncun
* 

